# Fail Ponteng AI Import Package v1.0

Pakej ini ialah arahan standard kepada AI untuk menukar data mentah kepada ZIP import
bagi aplikasi **Fail Kes Ponteng Digital**.

## Modul yang disokong
1. Nama Murid
2. Takwim
3. Kehadiran

AI boleh menerima bahan mentah dalam bentuk:
- Excel / CSV
- PDF
- gambar / foto
- jadual bercetak
- senarai nama
- laporan kehadiran
- takwim sekolah / negeri

AI kemudian menghasilkan **satu ZIP standard**.

## Struktur ZIP hasil AI

```text
manifest.json
murid/murid.csv                 # pilihan
takwim/takwim.csv               # pilihan
kehadiran/kehadiran.csv         # pilihan
kehadiran/*.csv                 # dibenarkan jika mahu pecah ikut bulan/kelas
validation.json
```

Sekurang-kurangnya satu daripada folder `murid`, `takwim` atau `kehadiran` mesti mempunyai data.

## Turutan import dalam aplikasi

Aplikasi perlu mengimport dalam turutan:
1. Murid
2. Takwim
3. Kehadiran

Ini penting kerana rekod kehadiran merujuk `no_murid`.

## Prinsip

- Jangan meneka data yang tidak jelas.
- Jangan cipta No. Murid/No. KP.
- Tarikh output standard: `DD/MM/YYYY`.
- Kehadiran mesti menggunakan status kanonik aplikasi.
- Nama murid dan kelas hendaklah konsisten.
- `no_murid` ialah kunci rujukan utama kehadiran.
- Semua isu yang tidak dapat dipastikan mesti dimasukkan dalam `validation.json.needs_review`.

Rujuk `01_ARAHAN_AI_PROSES_DATA_MENTAH.md`.
