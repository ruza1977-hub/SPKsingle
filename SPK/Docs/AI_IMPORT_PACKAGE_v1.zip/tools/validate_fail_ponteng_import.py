#!/usr/bin/env python3
import csv, io, json, re, sys, zipfile
from datetime import datetime
from pathlib import Path

VALID_STATUS = {"HADIR","TIDAK HADIR","PONTENG","MC","CUTI BERSEBAB","LEWAT"}

def decode(raw):
    for enc in ("utf-8-sig","utf-8","cp1252"):
        try: return raw.decode(enc)
        except UnicodeDecodeError: pass
    raise ValueError("Encoding CSV tidak disokong")

def read_csv(z, name):
    return list(csv.DictReader(io.StringIO(decode(z.read(name)))))

def valid_date(s):
    try:
        datetime.strptime((s or "").strip(), "%d/%m/%Y")
        return True
    except ValueError:
        return False

def main(path):
    errors=[]; warnings=[]; counts={"murid":0,"takwim":0,"kehadiran":0}
    student_ids=set(); calendar_dates=set(); att_keys=set()

    with zipfile.ZipFile(path) as z:
        names=[n for n in z.namelist() if not n.endswith("/")]
        if "manifest.json" not in names:
            errors.append("manifest.json tiada")
            manifest={}
        else:
            manifest=json.loads(z.read("manifest.json").decode("utf-8"))

        if manifest.get("package_type") != "fail_ponteng_import":
            errors.append("package_type mesti fail_ponteng_import")

        murid_files=[n for n in names if n.lower().startswith("murid/") and n.lower().endswith(".csv")]
        takwim_files=[n for n in names if n.lower().startswith("takwim/") and n.lower().endswith(".csv")]
        hadir_files=[n for n in names if n.lower().startswith("kehadiran/") and n.lower().endswith(".csv")]

        if not (murid_files or takwim_files or hadir_files):
            errors.append("Tiada modul data dalam ZIP")

        for name in murid_files:
            rows=read_csv(z,name)
            counts["murid"] += len(rows)
            for i,r in enumerate(rows,2):
                nama=(r.get("nama") or "").strip()
                no=(r.get("no_murid") or "").strip()
                kelas=(r.get("kelas") or "").strip()
                if not nama or not no or not kelas:
                    errors.append(f"{name}:{i} murid perlu nama,no_murid,kelas")
                    continue
                if no in student_ids:
                    warnings.append(f"{name}:{i} no_murid duplikat: {no}")
                student_ids.add(no)

        for name in takwim_files:
            rows=read_csv(z,name)
            counts["takwim"] += len(rows)
            for i,r in enumerate(rows,2):
                d=(r.get("tarikh") or "").strip()
                hp=(r.get("hari_persekolahan") or "").strip()
                if not valid_date(d):
                    errors.append(f"{name}:{i} tarikh tidak sah: {d}")
                if hp not in {"0","1"}:
                    errors.append(f"{name}:{i} hari_persekolahan mesti 0/1")
                if d in calendar_dates:
                    warnings.append(f"{name}:{i} tarikh takwim duplikat: {d}")
                calendar_dates.add(d)

        for name in hadir_files:
            rows=read_csv(z,name)
            counts["kehadiran"] += len(rows)
            for i,r in enumerate(rows,2):
                d=(r.get("tarikh") or "").strip()
                no=(r.get("no_murid") or "").strip()
                status=(r.get("status") or "").strip().upper()
                if not valid_date(d):
                    errors.append(f"{name}:{i} tarikh tidak sah: {d}")
                if not no:
                    errors.append(f"{name}:{i} no_murid kosong")
                if status not in VALID_STATUS:
                    errors.append(f"{name}:{i} status tidak sah: {status}")
                k=(d,no)
                if k in att_keys:
                    warnings.append(f"{name}:{i} kehadiran duplikat: {d}/{no}")
                att_keys.add(k)
                if student_ids and no not in student_ids:
                    warnings.append(f"{name}:{i} no_murid tiada dalam modul murid: {no}")

    result={
        "status":"OK" if not errors else "ERROR",
        "record_counts":counts,
        "errors":errors,
        "warnings":warnings
    }
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if not errors else 1

if __name__ == "__main__":
    if len(sys.argv)!=2:
        raise SystemExit("Guna: python validate_fail_ponteng_import.py fail.zip")
    raise SystemExit(main(sys.argv[1]))
