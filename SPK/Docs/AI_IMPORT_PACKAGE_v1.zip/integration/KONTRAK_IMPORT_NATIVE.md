# Kontrak Import ZIP — Fail Kes Ponteng Digital

## Format baharu
`package_type = fail_ponteng_import`

Importer aplikasi hendaklah:
1. buka ZIP;
2. baca dan sahkan `manifest.json`;
3. import `murid/*.csv`;
4. import `takwim/*.csv`;
5. import `kehadiran/*.csv`;
6. baca `validation.json` untuk memaklumkan pengguna jika pakej mempunyai `needs_review`.

## Keselamatan
- Jangan ekstrak path `../` daripada ZIP.
- Hadkan import kepada fail CSV/JSON yang diketahui.
- Import hendaklah transactional jika boleh.
- Rekod murid di-upsert berdasarkan `no_murid`.
- Takwim di-upsert berdasarkan `tarikh`.
- Kehadiran di-upsert berdasarkan `(no_murid, tarikh)` selepas `no_murid` dipadankan kepada student ID tempatan.

## Keserasian data sedia ada
### Murid
Selaras dengan importer Native:
`nama,no_murid,kelas,tingkatan,penjaga,telefon,alamat`

### Takwim
Selaras dengan importer Native:
`tarikh,jenis,tajuk,hari_persekolahan,minggu_akademik,catatan`

### Kehadiran
Selaras dengan struktur final Python:
`tarikh,no_murid,nama,kelas,status,kategori,sebab,catatan`

## Turutan wajib
Murid → Takwim → Kehadiran.

Dengan turutan ini, pakej lengkap boleh diimport dalam satu operasi.
